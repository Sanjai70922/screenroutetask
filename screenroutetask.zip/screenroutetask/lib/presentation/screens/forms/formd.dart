// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';

class FormDScreen extends StatefulWidget {
  const FormDScreen({super.key});

  @override
  State<FormDScreen> createState() => _FormDScreenState();
}

class _FormDScreenState extends State<FormDScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: formDColor,
      body: Center(child: Text('Form D')),
    );
  }
}
