// ignore_for_file: prefer_const_constructors

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';
import 'package:screenroutetask/presentation/routes/router.gr.dart';

class PersonalDetailsScreen extends StatefulWidget {
  const PersonalDetailsScreen({super.key});

  @override
  State<PersonalDetailsScreen> createState() => _PersonalDetailsScreenState();
}

class _PersonalDetailsScreenState extends State<PersonalDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: formColor,
      body: Padding(
        padding: EdgeInsets.all(100.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Personal Details',
                style: TextStyle(
                    color: textColor,
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold)),
            SizedBox(
              height: 50.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                  ],
                ),
                Column(
                  children: [
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 50.0,
            ),

             Center(
              child: Padding(
                padding: const EdgeInsets.all(5.0),
                child: ElevatedButton(
                  onPressed: () {
                   context.router.push(EducationalDetailsRoute());
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: secondaryColor,
                  ),
                  child: SizedBox(
                    height: 40.0,
                    width: 80.0,
                    // padding: EdgeInsets.all(10.0),
                    child: Center(
                      child: Text(
                        'Next',
                        style: TextStyle(
                            color: textColor,
                            fontSize: 14.0,
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            
          ],
        ),
      ),
    );
  }

  Widget button({
    double? height,
    double? width,
    String? text,
  }) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: ElevatedButton(
        onPressed: () {
          setState(() {
            // changeColor = !changeColor;
          });
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: secondaryColor,
        ),
        child: SizedBox(
          height: height,
          width: width,
          // padding: EdgeInsets.all(10.0),
          child: Center(
            child: Text(
              text!,
              style: TextStyle(
                  color: textColor,
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ),
      ),
    );
  }
}