// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';

class FormEScreen extends StatefulWidget {
  const FormEScreen({super.key});

  @override
  State<FormEScreen> createState() => _FormEScreenState();
}

class _FormEScreenState extends State<FormEScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: formEColor,
      body: Center(child: Text('Form E')),
    );
  }
}
