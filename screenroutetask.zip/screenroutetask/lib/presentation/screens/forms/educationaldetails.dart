// ignore_for_file: prefer_const_constructors

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';
import 'package:screenroutetask/presentation/routes/router.gr.dart';

class EducationalDetailsScreen extends StatefulWidget {
  const EducationalDetailsScreen({super.key});

  @override
  State<EducationalDetailsScreen> createState() => _EducationalDetailsScreenState();
}

class _EducationalDetailsScreenState extends State<EducationalDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: formColor,
      body: Padding(
        padding: EdgeInsets.all(100.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Educational Details',
                style: TextStyle(
                    color: textColor,
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold)),
            SizedBox(
              height: 50.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                  ],
                ),
                Column(
                  children: [
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                    button(height: 40.0, width: 150.0, text: 'First Name'),
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 50.0,
            ),
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: ElevatedButton(
                      onPressed: () {
                        context.router.push(FormRoute());
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: secondaryColor,
                      ),
                      child: SizedBox(
                        height: 40.0,
                        width: 80.0,
                        // padding: EdgeInsets.all(10.0),
                        child: Center(
                          child: Text(
                            'Back',
                            style: TextStyle(
                                color: textColor,
                                fontSize: 14.0,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: ElevatedButton(
                      onPressed: () {
                           context.router.push(SuccessRoute());
                        
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: secondaryColor,
                      ),
                      child: SizedBox(
                        height: 40.0,
                        width: 80.0,
                        // padding: EdgeInsets.all(10.0),
                        child: Center(
                          child: Text(
                            'Submit',
                            style: TextStyle(
                                color: textColor,
                                fontSize: 14.0,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
           
          ],
        ),
      ),
    );
  }

  Widget button({
    double? height,
    double? width,
    String? text,
  }) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: ElevatedButton(
        onPressed: () {
          setState(() {
            // changeColor = !changeColor;
          });
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: secondaryColor,
        ),
        child: SizedBox(
          height: height,
          width: width,
          // padding: EdgeInsets.all(10.0),
          child: Center(
            child: Text(
              text!,
              style: TextStyle(
                  color: textColor,
                  fontSize: 14.0,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ),
      ),
    );
  }
}
