// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';

class FormFScreen extends StatefulWidget {
  const FormFScreen({super.key});

  @override
  State<FormFScreen> createState() => _FormFScreenState();
}

class _FormFScreenState extends State<FormFScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: formFColor,
      body: Center(child: Text('Form F')),
    );
  }
}
