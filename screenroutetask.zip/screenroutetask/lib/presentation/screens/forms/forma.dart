// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';

class FormAScreen extends StatefulWidget {
  const FormAScreen({super.key});

  @override
  State<FormAScreen> createState() => _FormAScreenState();
}

class _FormAScreenState extends State<FormAScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: formAColor,
      body: Center(child: Text('Form A')),
    );
  }
}
