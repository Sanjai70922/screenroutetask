// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';

class FormCScreen extends StatefulWidget {
  const FormCScreen({super.key});

  @override
  State<FormCScreen> createState() => _FormCScreenState();
}

class _FormCScreenState extends State<FormCScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: formCColor,
      body: Center(child: Text('Form C',style: TextStyle(color: Colors.white),)),
    );
  }
}
