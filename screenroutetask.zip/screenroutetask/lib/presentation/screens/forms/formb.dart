// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';

class FormBScreen extends StatefulWidget {
  const FormBScreen({super.key});

  @override
  State<FormBScreen> createState() => _FormBScreenState();
}

class _FormBScreenState extends State<FormBScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: formBColor,
      body: Center(child: Text('Form B')),
    );
  }
}
