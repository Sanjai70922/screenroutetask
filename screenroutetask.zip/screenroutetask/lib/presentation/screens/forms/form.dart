// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';
import 'package:screenroutetask/presentation/screens/forms/educationaldetails.dart';

class FormScreen extends StatefulWidget {
  const FormScreen({super.key});

  @override
  State<FormScreen> createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
 void next() {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => EducationalDetailsScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: formColor,
      body: Center(child: Text('Form Page'),),);
  }
}
