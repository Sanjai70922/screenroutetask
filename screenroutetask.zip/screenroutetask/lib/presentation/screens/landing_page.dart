// ignore_for_file: prefer_const_constructors

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:screenroutetask/presentation/common/constants.dart';
import 'package:screenroutetask/presentation/routes/router.gr.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  bool _homePressed = false;
  bool _formPressed = false;
  bool _careerPressed = false;
  bool _formaPressed = false;
  bool _formbPressed = false;
  bool _formcPressed = false;
  bool _formdPressed = false;
  bool _formePressed = false;
  bool _formfPressed = false;

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: secondaryColor,
      // appBar: AppBar(),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(right: 24.0),
              child: Container(
                // padding: EdgeInsets.all(50.0),
                height: height,
                width: width * 0.18,

                decoration: const BoxDecoration(
                  color: primaryColor,
                  borderRadius: BorderRadius.all(Radius.circular(4.0)),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: ElevatedButton(
                        onPressed: () {
                          context.router.push(FormARoute());
                          setState(() {
                            _formaPressed = true;
                            _careerPressed = false;
                            _formPressed = false;
                            _formbPressed = false;
                            _formcPressed = false;
                            _formdPressed = false;
                            _formePressed = false;
                            _formfPressed = false;
                            _homePressed = false;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor:
                                _formaPressed ? formColor : secondaryColor),
                        child: SizedBox(
                          height: 40.0,
                          width: double.infinity,
                          // padding: EdgeInsets.all(10.0),
                          child: Center(
                            child: Text(
                              'Form A',
                              style: TextStyle(
                                  color: textColor,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: ElevatedButton(
                        onPressed: () {
                          context.router.push(FormBRoute());
                          setState(() {
                            _formaPressed = false;
                            _formbPressed = true;
                            _formcPressed = false;
                            _formPressed = false;
                            _careerPressed = false;
                            _homePressed = false;
                            _formdPressed = false;
                            _formePressed = false;
                            _formfPressed = false;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor:
                                _formbPressed ? formColor : secondaryColor),
                        child: SizedBox(
                          height: 40.0,
                          width: double.infinity,
                          // padding: EdgeInsets.all(10.0),
                          child: Center(
                            child: Text(
                              'Form B',
                              style: TextStyle(
                                  color: textColor,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: ElevatedButton(
                        onPressed: () {
                          context.router.push(FormCRoute());
                          setState(() {
                            _formaPressed = false;
                            _formbPressed = false;
                            _formcPressed = true;
                            _formPressed = false;
                            _careerPressed = false;
                            _homePressed = false;
                            _formdPressed = false;
                            _formePressed = false;
                            _formfPressed = false;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor:
                                _formcPressed ? formColor : secondaryColor),
                        child: SizedBox(
                          height: 40.0,
                          width: double.infinity,
                          // padding: EdgeInsets.all(10.0),
                          child: Center(
                            child: Text(
                              'Form C',
                              style: TextStyle(
                                  color: textColor,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(right: 24.0, bottom: 15.0),
                  child: Container(
                    // padding: EdgeInsets.all(50.0),
                    height: height * 0.06,
                    width: width * 0.59,

                    decoration: const BoxDecoration(
                      color: primaryColor,
                      borderRadius: BorderRadius.all(Radius.circular(4.0)),
                    ),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: ElevatedButton(
                            onPressed: () {
                              context.router.push(HomeRoute());
                              setState(() {
                                _formaPressed = false;
                                _formbPressed = false;
                                _formcPressed = false;
                                _homePressed = true;
                                _careerPressed = false;
                                _formPressed = false;
                                _formdPressed = false;
                                _formePressed = false;
                                _formfPressed = false;
                              });
                            },
                            style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    _homePressed ? formColor : secondaryColor),
                            child: SizedBox(
                              height: height,
                              width: 40.0,
                              // padding: EdgeInsets.all(10.0),
                              child: Center(
                                child: Text(
                                  'Home',
                                  style: TextStyle(
                                      color: textColor,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: ElevatedButton(
                            onPressed: () {
                              context.router.push(FormRoute());
                              setState(() {
                                _formaPressed = false;
                                _formbPressed = false;
                                _formcPressed = false;
                                _homePressed = false;
                                _formPressed = true;
                                _careerPressed = false;                               
                                _formdPressed = false;
                                _formePressed = false;
                                _formfPressed = false;
                              });
                            },
                            style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    _formPressed ? formColor : secondaryColor),
                            child: SizedBox(
                              height: height,
                              width: 40.0,
                              // padding: EdgeInsets.all(10.0),
                              child: Center(
                                child: Text(
                                  'Form',
                                  style: TextStyle(
                                      color: textColor,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: ElevatedButton(
                            onPressed: () {
                              context.router.push(CareerRoute());
                              setState(() {
                                _formaPressed = false;
                                _formbPressed = false;
                                _formcPressed = false;
                                _homePressed = false;
                                _formPressed = false;
                                _careerPressed = true;
                                _formdPressed = false;
                                _formePressed = false;
                                _formfPressed = false;
                              });
                            },
                            style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    _careerPressed ? formColor : secondaryColor),
                            child: SizedBox(
                              height: height,
                              width: 40.0,
                              // padding: EdgeInsets.all(10.0),
                              child: Center(
                                child: Text(
                                  'career',
                                  style: TextStyle(
                                      color: textColor,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 24.0),
                    child: Container(
                      // padding: EdgeInsets.all(50.0),
                      height: height,
                      width: width * 0.59,

                      decoration: const BoxDecoration(
                        color: primaryColor,
                        borderRadius: BorderRadius.all(Radius.circular(4.0)),
                      ),
                      child: AutoRouter(),
                    ),
                  ),
                ),
              ],
            ),
            Expanded(
              child: Container(
                // padding: EdgeInsets.all(50.0),
                height: height,
                width: width * 0.18,
            
                decoration: const BoxDecoration(
                  color: primaryColor,
                  borderRadius: BorderRadius.all(Radius.circular(4.0)),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: ElevatedButton(
                        onPressed: () {
                          context.router.push(FormDRoute());
                          setState(() {
                            _formaPressed = false;
                            _formbPressed = false;
                            _formcPressed = false;
                            _homePressed = false;
                            _careerPressed = false;
                            _formPressed = false;
                            _formdPressed = true;
                            _formePressed = false;
                            _formfPressed = false;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: _formdPressed ? formColor : secondaryColor),
                        child: SizedBox(
                          height: 40.0,
                          width: double.infinity,
                          // padding: EdgeInsets.all(10.0),
                          child: Center(
                            child: Text(
                              'Form D',
                              style: TextStyle(
                                  color: textColor,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: ElevatedButton(
                        onPressed: () {
                          context.router.push(FormERoute());
                          setState(() {
                            _formaPressed = false;
                            _formbPressed = false;
                            _formcPressed = false;
                            _homePressed = false;
                            _careerPressed = false;
                            _formPressed = false;
                            _formdPressed = false;
                            _formePressed = true;
                            _formfPressed = false;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: _formePressed ? formColor : secondaryColor),
                        child: SizedBox(
                          height: 40.0,
                          width: double.infinity,
                          // padding: EdgeInsets.all(10.0),
                          child: Center(
                            child: Text(
                              'Form E',
                              style: TextStyle(
                                  color: textColor,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: ElevatedButton(
                        onPressed: () {
                          context.router.push(FormFRoute());
                          setState(() {
                            _formaPressed = false;
                            _formbPressed = false;
                            _formcPressed = false;
                            _homePressed = false;
                            _careerPressed = false;
                            _formPressed = false;
                            _formdPressed = false;
                            _formePressed = false;
                            _formfPressed = true;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                            backgroundColor: _formfPressed ? formColor : secondaryColor),
                        child: SizedBox(
                          height: 40.0,
                          width: double.infinity,
                          // padding: EdgeInsets.all(10.0),
                          child: Center(
                            child: Text(
                              'Form F',
                              style: TextStyle(
                                  color: textColor,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
