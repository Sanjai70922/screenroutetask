// **************************************************************************
// AutoRouteGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouteGenerator
// **************************************************************************
//
// ignore_for_file: type=lint

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:auto_route/auto_route.dart' as _i14;
import 'package:flutter/material.dart' as _i15;

import '../screens/forms/career.dart' as _i5;
import '../screens/forms/educationaldetails.dart' as _i12;
import '../screens/forms/form.dart' as _i4;
import '../screens/forms/forma.dart' as _i6;
import '../screens/forms/formb.dart' as _i7;
import '../screens/forms/formc.dart' as _i8;
import '../screens/forms/formd.dart' as _i9;
import '../screens/forms/forme.dart' as _i10;
import '../screens/forms/formf.dart' as _i11;
import '../screens/forms/home.dart' as _i3;
import '../screens/forms/success.dart' as _i13;
import '../screens/intialscreen.dart' as _i2;
import '../screens/landing_page.dart' as _i1;

class AppRouter extends _i14.RootStackRouter {
  AppRouter([_i15.GlobalKey<_i15.NavigatorState>? navigatorKey])
      : super(navigatorKey);

  @override
  final Map<String, _i14.PageFactory> pagesMap = {
    LandingPage.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i1.LandingPage(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    InitialRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i2.InitialScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    HomeRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i3.HomeScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    FormRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i4.FormScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    CareerRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i5.CareerScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    FormARoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i6.FormAScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    FormBRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i7.FormBScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    FormCRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i8.FormCScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    FormDRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i9.FormDScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    FormERoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i10.FormEScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    FormFRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i11.FormFScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    EducationalDetailsRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i12.EducationalDetailsScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
    SuccessRoute.name: (routeData) {
      return _i14.CustomPage<dynamic>(
        routeData: routeData,
        child: const _i13.SuccessScreen(),
        transitionsBuilder: _i14.TransitionsBuilders.fadeIn,
        opaque: true,
        barrierDismissible: false,
      );
    },
  };

  @override
  List<_i14.RouteConfig> get routes => [
        _i14.RouteConfig(
          LandingPage.name,
          path: '/',
          children: [
            _i14.RouteConfig(
              InitialRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              HomeRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              FormRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              CareerRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              FormARoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              FormBRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              FormCRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              FormDRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              FormERoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              FormFRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              EducationalDetailsRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
            _i14.RouteConfig(
              SuccessRoute.name,
              path: '',
              parent: LandingPage.name,
            ),
          ],
        )
      ];
}

/// generated route for
/// [_i1.LandingPage]
class LandingPage extends _i14.PageRouteInfo<void> {
  const LandingPage({List<_i14.PageRouteInfo>? children})
      : super(
          LandingPage.name,
          path: '/',
          initialChildren: children,
        );

  static const String name = 'LandingPage';
}

/// generated route for
/// [_i2.InitialScreen]
class InitialRoute extends _i14.PageRouteInfo<void> {
  const InitialRoute()
      : super(
          InitialRoute.name,
          path: '',
        );

  static const String name = 'InitialRoute';
}

/// generated route for
/// [_i3.HomeScreen]
class HomeRoute extends _i14.PageRouteInfo<void> {
  const HomeRoute()
      : super(
          HomeRoute.name,
          path: '',
        );

  static const String name = 'HomeRoute';
}

/// generated route for
/// [_i4.FormScreen]
class FormRoute extends _i14.PageRouteInfo<void> {
  const FormRoute()
      : super(
          FormRoute.name,
          path: '',
        );

  static const String name = 'FormRoute';
}

/// generated route for
/// [_i5.CareerScreen]
class CareerRoute extends _i14.PageRouteInfo<void> {
  const CareerRoute()
      : super(
          CareerRoute.name,
          path: '',
        );

  static const String name = 'CareerRoute';
}

/// generated route for
/// [_i6.FormAScreen]
class FormARoute extends _i14.PageRouteInfo<void> {
  const FormARoute()
      : super(
          FormARoute.name,
          path: '',
        );

  static const String name = 'FormARoute';
}

/// generated route for
/// [_i7.FormBScreen]
class FormBRoute extends _i14.PageRouteInfo<void> {
  const FormBRoute()
      : super(
          FormBRoute.name,
          path: '',
        );

  static const String name = 'FormBRoute';
}

/// generated route for
/// [_i8.FormCScreen]
class FormCRoute extends _i14.PageRouteInfo<void> {
  const FormCRoute()
      : super(
          FormCRoute.name,
          path: '',
        );

  static const String name = 'FormCRoute';
}

/// generated route for
/// [_i9.FormDScreen]
class FormDRoute extends _i14.PageRouteInfo<void> {
  const FormDRoute()
      : super(
          FormDRoute.name,
          path: '',
        );

  static const String name = 'FormDRoute';
}

/// generated route for
/// [_i10.FormEScreen]
class FormERoute extends _i14.PageRouteInfo<void> {
  const FormERoute()
      : super(
          FormERoute.name,
          path: '',
        );

  static const String name = 'FormERoute';
}

/// generated route for
/// [_i11.FormFScreen]
class FormFRoute extends _i14.PageRouteInfo<void> {
  const FormFRoute()
      : super(
          FormFRoute.name,
          path: '',
        );

  static const String name = 'FormFRoute';
}

/// generated route for
/// [_i12.EducationalDetailsScreen]
class EducationalDetailsRoute extends _i14.PageRouteInfo<void> {
  const EducationalDetailsRoute()
      : super(
          EducationalDetailsRoute.name,
          path: '',
        );

  static const String name = 'EducationalDetailsRoute';
}

/// generated route for
/// [_i13.SuccessScreen]
class SuccessRoute extends _i14.PageRouteInfo<void> {
  const SuccessRoute()
      : super(
          SuccessRoute.name,
          path: '',
        );

  static const String name = 'SuccessRoute';
}
