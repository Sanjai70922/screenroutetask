import 'package:auto_route/auto_route.dart';
import 'package:screenroutetask/presentation/screens/forms/career.dart';
import 'package:screenroutetask/presentation/screens/forms/educationaldetails.dart';
import 'package:screenroutetask/presentation/screens/forms/form.dart';
import 'package:screenroutetask/presentation/screens/forms/forma.dart';
import 'package:screenroutetask/presentation/screens/forms/formb.dart';
import 'package:screenroutetask/presentation/screens/forms/formc.dart';
import 'package:screenroutetask/presentation/screens/forms/formd.dart';
import 'package:screenroutetask/presentation/screens/forms/forme.dart';
import 'package:screenroutetask/presentation/screens/forms/formf.dart';
import 'package:screenroutetask/presentation/screens/forms/home.dart';
import 'package:screenroutetask/presentation/screens/forms/success.dart';
import 'package:screenroutetask/presentation/screens/intialscreen.dart';
import 'package:screenroutetask/presentation/screens/landing_page.dart';

@CustomAutoRouter(
    replaceInRouteName: 'Screen,Route',
    transitionsBuilder: TransitionsBuilders.fadeIn,
    routes: [
      AutoRoute(
        path: '/',
        page: LandingPage,
        children: [
          AutoRoute(path: '', page: InitialScreen, initial: true, children: []),
          AutoRoute(path: '', page: HomeScreen, children: []),
          AutoRoute(path: '', page: FormScreen, children: []),
          AutoRoute(path: '', page: CareerScreen, children: []),
          AutoRoute(path: '', page: FormAScreen, children: []),
          AutoRoute(path: '', page: FormBScreen, children: []),
          AutoRoute(path: '', page: FormCScreen, children: []),
          AutoRoute(path: '', page: FormDScreen, children: []),
          AutoRoute(path: '', page: FormEScreen, children: []),
          AutoRoute(path: '', page: FormFScreen, children: []),
          AutoRoute(path: '', page: EducationalDetailsScreen, children: []),
          AutoRoute(path: '', page: SuccessScreen, children: []),
        ],
      ),
    ])
class $AppRouter {}
