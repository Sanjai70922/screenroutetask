import 'package:flutter/material.dart';

const primaryColor = Colors.white;
const secondaryColor = Colors.grey;
const textColor = Colors.black;
const homeColor=Colors.white;
const formColor=Colors.orangeAccent;
const careerColor=Colors.redAccent;
const formAColor=Colors.blueAccent;
const formBColor=Colors.limeAccent;
const formCColor=Colors.black;
const formDColor=Colors.purple;
const formEColor=Colors.greenAccent;
const formFColor=Colors.blue;